package model.GameObjects;

/**
 * Created by ASUS on 08/12/2016.
 */
public enum Direction {
    UP, DOWN, LEFT, RIGHT
}
