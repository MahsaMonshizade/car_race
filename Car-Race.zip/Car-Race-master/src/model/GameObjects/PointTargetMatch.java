package model.GameObjects;

/**
 * Created by ASUS on 10/12/2016.
 */
public class PointTargetMatch extends Match {

    public PointTargetMatch(String path) {
        super(path);
    }
}
