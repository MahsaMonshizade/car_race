package model.GameObjects;

/**
 * Created by ASUS on 15/12/2016.
 */
public class StraightTimeMatch extends Match {

    public StraightTimeMatch(String path) {
        super(path);
        matchType = "StraightTimeMatch";
    }
}
